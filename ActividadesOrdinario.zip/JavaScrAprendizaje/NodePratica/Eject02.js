/*const saludame = require("./eject.js");

console.log(saludame.saludo("Javier")); */

function sayHelloWorld(){
    return "Que rollo con el pollo!";
}

module.exports.HolaUni = sayHelloWorld;

console.log(module.exports);