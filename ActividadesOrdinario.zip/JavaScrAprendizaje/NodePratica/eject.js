/* function sayHello(name){
    return `Hello, ${name}!`;
}


function sayHelloWorld(){
    return "Hello, World!";
}

module.exports.saludo = sayHello; 

console.log(module.exports); */

const HolaUniverso = require("./Eject02.js");

console.log(HolaUniverso.HolaUni("Que rollo con el pollo"));
