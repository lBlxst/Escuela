const cuadro = document.querySelector('#mi_ID');
cuadro.textContent = "Este texto viene desde JavaScript";

const contenedor = document.querySelector(".miClase");
contenedor.textContent = "Este texto viene desde JavaScript también";


function logEvent(event) {
    console.log(`El evento ${event.type} fue disparado`);
}


function agregarClase() {
    contenedor.classList.toggle('claseNueva');
}


contenedor.addEventListener('click', agregarClase);

cuadro.addEventListener('click', () => {
    cuadro.innerText = "Hiciste click en el contenedor";
});

cuadro.addEventListener('dblclick', () => {
    cuadro.textContent = "";
});

// Agregar eventos de mouse al cuadro
cuadro.addEventListener('mouseover', logEvent);
cuadro.addEventListener('mousedown', logEvent);
cuadro.addEventListener('mouseup', logEvent);
cuadro.addEventListener('mousemove', logEvent);
cuadro.addEventListener('mouseout', logEvent);