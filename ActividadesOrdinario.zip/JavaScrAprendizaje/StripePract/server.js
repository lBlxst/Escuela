require("dotenv").config();
const express = require("express");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

app.post("/pay", async (req, res) => {
    try {
        const { amount, payment_method_id } = req.body; // Ahora recibimos el método de pago
        if (!amount || amount <= 0) {
            return res.status(400).json({ error: "Monto inválido" });
        }

        // Crear intento de pago con método de pago
        const paymentIntent = await stripe.paymentIntents.create({
            amount,
            currency: "usd",
            payment_method: payment_method_id, // Se vincula el método de pago
            confirm: true, // Confirmar pago inmediatamente
        });

        res.json({ clientSecret: paymentIntent.client_secret, paymentIntent });
    } catch (error) {
        console.error("❌ Error en pago:", error.message);
        res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
});