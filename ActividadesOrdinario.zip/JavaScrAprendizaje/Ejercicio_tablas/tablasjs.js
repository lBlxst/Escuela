const usuarios = [
    {
        id: 1,
        nombre: "Juan",
        apellido: "Pérez",
        correo: "juan.perez@example.com",
        telefono: "555-123-4567",
        comentario: "Comentario de ejemplo 1"
    },
    {
        id: 2,
        nombre: "Ana",
        apellido: "Gómez",
        correo: "ana.gomez@example.com",
        telefono: "555-987-6543",
        comentario: "Comentario de ejemplo 2"
    },
    {
        id: 3,
        nombre: "Carlos",
        apellido: "Martínez",
        correo: "carlos.martinez@example.com",
        telefono: "555-654-3210",
        comentario: "Comentario de ejemplo 3"
    },
    {
        id: 4,
        nombre: "Lucía",
        apellido: "Fernández",
        correo: "lucia.fernandez@example.com",
        telefono: "555-876-5432",
        comentario: "Comentario de ejemplo 4"
    },
    {
        id: 5,
        nombre: "Diego",
        apellido: "López",
        correo: "diego.lopez@example.com",
        telefono: "555-234-5678",
        comentario: "Comentario de ejemplo 5"
    },
    {
        id: 6,
        nombre: "Sofía",
        apellido: "Ramírez",
        correo: "sofia.ramirez@example.com",
        telefono: "555-345-6789",
        comentario: "Comentario de ejemplo 6"
    },
    {
        id: 7,
        nombre: "Mario",
        apellido: "Hernández",
        correo: "mario.hernandez@example.com",
        telefono: "555-456-7890",
        comentario: "Comentario de ejemplo 7"
    },
    {
        id: 8,
        nombre: "Camila",
        apellido: "Sánchez",
        correo: "camila.sanchez@example.com",
        telefono: "555-567-8901",
        comentario: "Comentario de ejemplo 8"
    },
    {
        id: 9,
        nombre: "Miguel",
        apellido: "Torres",
        correo: "miguel.torres@example.com",
        telefono: "555-678-9012",
        comentario: "Comentario de ejemplo 9"
    },
    {
        id: 10,
        nombre: "Isabel",
        apellido: "Vargas",
        correo: "isabel.vargas@example.com",
        telefono: "555-789-0123",
        comentario: "Comentario de ejemplo 10"
    }
];

const tabla = document.querySelector('#tabla');

function crearTabla() {
    let cadena = "<table><thead>";
    cadena += "<tr><th>ID</th>";
    cadena += "<th>Nombre</th>";
    cadena += "<th>Apellido</th>";
    cadena += "<th>Correo</th>";
    cadena += "<th>Teléfono</th>";
    cadena += "<th>Comentario</th></tr></thead>";
    cadena += "<tbody>";

    for (const usuario of usuarios) {
        cadena += "<tr>";
        cadena += "<td>" + usuario.id + "</td>";
        cadena += "<td>" + usuario.nombre + "</td>";
        cadena += "<td>" + usuario.apellido + "</td>";
        cadena += "<td>" + usuario.correo + "</td>";
        cadena += "<td>" + usuario.telefono + "</td>";
        cadena += "<td>" + usuario.comentario + "</td>"; 
        cadena += "</tr>"; 
    }
    cadena += "</tbody>";
    cadena += "</table>";
    tabla.innerHTML = cadena;
}

crearTabla();

function agregarFila() {
    const id = document.getElementById("id").value;
    const nombre = document.getElementById("nombre").value;
    const apellido = document.getElementById("apellido").value;
    const correo = document.getElementById("correo").value;
    const telefono = document.getElementById("telefono").value;
    const comentario = document.getElementById("comentario").value;

    if (id && nombre && apellido && correo && telefono && comentario) {
        let contenedor = tabla.getElementsByTagName("tbody")[0];
        const nuevaFila = contenedor.insertRow();

        nuevaFila.innerHTML = `
            <td>${id}</td>
            <td>${nombre}</td>
            <td>${apellido}</td>
            <td>${correo}</td>
            <td>${telefono}</td>
            <td>${comentario}</td>
        `;
        document.getElementById('formulario').reset();
    } else {
        alert("Datos incompletos");
    }
}